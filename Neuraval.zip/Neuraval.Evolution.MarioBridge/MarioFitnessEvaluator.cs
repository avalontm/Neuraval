using Neuraval.Evolution;

namespace Neuraval.Evolution.MarioBridge
{
    public sealed class MarioFitnessEvaluator : IFitnessEvaluator<MarioAgent, SnesState, SnesAction>
    {
        private readonly int _maxSteps;

        // Bonus grande y plano cuando el agente termina el episodio por
        // completar el nivel (no por morir ni por reset manual). bestX ya
        // premia avanzar, pero sin esto a la evolucion le da lo mismo
        // "casi llegar" que "llegar" - este empujon hace que terminar el
        // nivel sea claramente mejor que cualquier bestX intermedio.
        private const float LevelCompleteBonus = 5000f;

        public MarioFitnessEvaluator(int maxSteps)
        {
            _maxSteps = maxSteps;
        }

        public float Evaluate(MarioAgent agent, IEnvironment<SnesState, SnesAction> environment)
        {
            var state = environment.Reset();
            var bestX = state.MarioX;

            for (var step = 0; step < _maxSteps; step++)
            {
                var action = agent.Decide(state);
                var result = environment.Step(action);
                state = result.State;

                if (state.MarioX > bestX)
                {
                    bestX = state.MarioX;
                }

                // El episodio se corta si Mario muere, si completa el nivel
                // (llega a la meta) o si se pidio un reset manual desde
                // BizHawk. _maxSteps sigue siendo un techo de seguridad para
                // no quedarse atado a un agente para siempre si nada de eso
                // pasa.
                if (result.Done)
                {
                    break;
                }
            }

            float fitness = bestX;

            if (state.IsLevelComplete)
            {
                fitness += LevelCompleteBonus;
            }

            return fitness;
        }
    }
}
